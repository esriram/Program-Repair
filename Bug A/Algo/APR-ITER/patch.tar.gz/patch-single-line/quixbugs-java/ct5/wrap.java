--- 
+++ 
@@ -11,6 +11,8 @@
         text = text.substring(end);
         lines.add(line);
     }
-
+//lines.add(text);
+            lines.add(text);//} //
+           ////= 0; //line;; //1; //line =text.length(); line =}//lines.add(line);;;
     return lines;
 }
