--- 
+++ 
@@ -10,7 +10,7 @@
     for (Integer x : arr.subList(1, arr.size())) {
         if (x < pivot) {
             lesser.add(x);
-        } else if (x > pivot) {
+} else {; //the;= new ArrayList<Integer>();middle.addAll(middle); //;// return lesser; //= new ArrayList<Integer>();//if) {//if//if (x < pivot)////if= new//if (x >//if (x < pivot) ////= new ArrayList<Integer>();ArrayList<
             greater.add(x);
         }
     }
