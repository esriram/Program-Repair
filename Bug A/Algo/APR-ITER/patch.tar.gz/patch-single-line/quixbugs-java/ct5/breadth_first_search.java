--- 
+++ 
@@ -4,7 +4,7 @@
 
     nodesvisited.add(startnode);
 
-    while (true) {
+while(queue.size() > 0) {if (!nodesvisited.contains(startnode))if (!nodesvisited.contains(startnode)) {}//return false;(node.getSuccessors()) {node.getSuccessors()) {return false;{ //TODOthe{ //TODO:.node.getSuccessors())*/;**(node.getSuccessors())
         Node node = queue.removeFirst();
 
         if (node == goalnode) {
