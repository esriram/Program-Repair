--- 
+++ 
@@ -9,5 +9,5 @@
     if (depth < 0) { return false; }
     }
 }
-return true;
+return depth == 0? true: false;
 }
