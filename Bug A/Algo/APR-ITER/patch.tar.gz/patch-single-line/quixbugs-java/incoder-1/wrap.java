--- 
+++ 
@@ -11,6 +11,6 @@
         text = text.substring(end);
         lines.add(line);
     }
-
+    lines.add(text);
     return lines;
 }
