--- 
+++ 
@@ -6,7 +6,7 @@
 
     for (int r=1; r<n; r++) {
         ArrayList<Integer> row = new ArrayList<Integer>();
-        for (int c=0; c<r; c++) {
+        for (int c=0; c<=r; c++) {
             int upleft, upright;
             if (c > 0) {
                 upleft = rows.get(r-1).get(c-1);
