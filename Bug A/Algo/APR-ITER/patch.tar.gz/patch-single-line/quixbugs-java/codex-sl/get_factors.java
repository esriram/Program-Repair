--- 
+++ 
@@ -11,5 +11,5 @@
             return prepend;
         }
     }
-    return new ArrayList<Integer>();
+    return new ArrayList<Integer>(Arrays.asList(n));
 }
