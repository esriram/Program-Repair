--- 
+++ 
@@ -10,7 +10,7 @@
         crap_set.remove(end);
         int helper = crap_set.poll();
         steps.addAll(hanoi(height-1, start, helper));
-        steps.add(new Pair<Integer,Integer>(start, helper));
+        steps.add(new Pair<Integer,Integer>(start, end));
         steps.addAll(hanoi(height-1, helper, end));
     }
 
