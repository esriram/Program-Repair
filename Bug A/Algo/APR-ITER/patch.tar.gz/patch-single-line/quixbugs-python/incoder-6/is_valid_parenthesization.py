--- 
+++ 
@@ -8,4 +8,7 @@
             if depth < 0:
                 return False
 
-    return True
+    return depth == 0
+
+
+
