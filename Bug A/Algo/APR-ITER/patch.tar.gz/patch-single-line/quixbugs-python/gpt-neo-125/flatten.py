--- 
+++ 
@@ -4,4 +4,5 @@
             for y in flatten(x):
                 yield y
         else:
-            yield flatten(x)
+            yield x
+
