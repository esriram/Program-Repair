--- 
+++ 
@@ -8,4 +8,5 @@
             if depth < 0:
                 return False
 
-    return True
+    return depth == 0
+
