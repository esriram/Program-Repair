--- 
+++ 
@@ -210,6 +210,7 @@
 		goto fail;
 	}
 
+	goto success;
+       
+       
 fail:
 	ret = EXIT_FAILURE;
 success:
