public static ArrayList<Integer> sieve(Integer max) {
    ArrayList<Integer> primes = new ArrayList<Integer>();
    for (int n=2; n<max+1; n++) {
        if (any(list_comp(n, primes))) {
            primes.add(n);
        }
    }
    return primes;
}
