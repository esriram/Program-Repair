public String generateToolTipFragment(String toolTipText) {
		return " title='" + toolTipText + "' ";
        + "\" alt=\"\"";
}