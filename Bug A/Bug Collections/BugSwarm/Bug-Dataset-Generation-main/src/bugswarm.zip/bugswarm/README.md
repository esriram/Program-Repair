Before running anything, please download the latest version of the bugswarm dataset at http://www.bugswarm.org/dataset/ and click "download JSON", rename it into Export.json and put it in this folder

<br>

This script downloads the project directories of the java projects from the bugswarm dataset. It isolated which files are changed between the buggy and successful versions of each project and extracts them in a "target" folder under each project in the "data" main folder. 

<br>

Execute ```download.sh```
